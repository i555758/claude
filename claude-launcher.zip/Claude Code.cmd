@echo off
title Claude Code Launcher
color 0B


:: Verificar se o proxy já está rodando
curl -s -o nul -w "%%{http_code}" http://localhost:6655/ 2>nul | findstr /C:"200" >nul 2>&1
if %errorlevel%==0 (
    echo [OK] HAI Proxy ja esta rodando na porta 6655.
    goto start_claude
)

:: Iniciar o proxy em background
echo [..] Iniciando HAI Proxy...
start "HAI Proxy" /min "C:\SAPDevelop\hai\hai.exe" proxy start --headless

:: Aguardar proxy ficar pronto (até 30s)
set /a tries=0
:wait_loop
timeout /t 1 /nobreak >nul
set /a tries+=1
curl -s -o nul -w "%%{http_code}" http://localhost:6655/ 2>nul | findstr /C:"200" >nul 2>&1
if %errorlevel%==0 goto proxy_ready
if %tries% lss 30 goto wait_loop

echo [!] Proxy demorou mais que o esperado. Continuando mesmo assim...
goto start_claude

:proxy_ready
echo [OK] HAI Proxy pronto (%tries%s).

:: Aguardar estabilizacao do proxy antes de iniciar o Claude
timeout /t 3 /nobreak >nul

:start_claude
echo [..] Abrindo Claude Code...
claude
