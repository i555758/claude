@echo off
title Instalador Claude Code Launcher
color 0B

echo.
echo   ----------------------------------------
echo    Instalador do Claude Code Launcher
echo   ----------------------------------------
echo.

:: Diretorio de instalacao
set INSTALL_DIR=C:\SAPDevelop\claude-launcher
set DESKTOP=%USERPROFILE%\Desktop

:: Criar diretorio
echo [..] Criando diretorio de instalacao...
if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"

:: Copiar arquivos
echo [..] Copiando arquivos...
copy /Y "%~dp0Claude Code.cmd" "%INSTALL_DIR%\Claude Code.cmd" >nul
copy /Y "%~dp0claude-code.ico" "%INSTALL_DIR%\claude-code.ico" >nul

:: Verificar se os arquivos foram copiados
if not exist "%INSTALL_DIR%\Claude Code.cmd" (
    echo [!] ERRO: Falha ao copiar Claude Code.cmd
    pause
    exit /b 1
)
if not exist "%INSTALL_DIR%\claude-code.ico" (
    echo [!] ERRO: Falha ao copiar claude-code.ico
    pause
    exit /b 1
)

:: Criar atalho na Desktop
echo [..] Criando atalho na Desktop...
powershell -Command "$ws = New-Object -ComObject WScript.Shell; $s = $ws.CreateShortcut('%DESKTOP%\Claude Code.lnk'); $s.TargetPath = '%INSTALL_DIR%\Claude Code.cmd'; $s.IconLocation = '%INSTALL_DIR%\claude-code.ico'; $s.Description = 'Claude Code com HAI Proxy'; $s.Save()"

if exist "%DESKTOP%\Claude Code.lnk" (
    echo [OK] Atalho criado na Desktop com sucesso!
) else (
    echo [!] ERRO: Falha ao criar atalho na Desktop.
    pause
    exit /b 1
)

echo.
echo   ----------------------------------------
echo    Instalacao concluida com sucesso!
echo    Use o atalho "Claude Code" na Desktop.
echo   ----------------------------------------
echo.
pause
